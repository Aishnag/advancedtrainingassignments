package com.assignments;

public class Assignment1_2 {

	
}

class Rectangle{
	
}

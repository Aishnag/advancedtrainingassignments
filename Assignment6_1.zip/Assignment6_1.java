package com.assignment6;

import java.util.ArrayList;

public class Assignment6_1 {

	public static void main(String[] args) {
		ArrayList<String> alist = new ArrayList();
		alist.add("Steve");
	      alist.add("Tim");
	      alist.add("Lucy");
	      alist.add("Pat");
	      alist.add("Angela");
	      alist.add("Tom");
	      System.out.println(alist);
	      
	   System.out.println(alist.contains("Tim"));
		
	}
}
